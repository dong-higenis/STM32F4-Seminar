#ifndef EVT_CODE_H_
#define EVT_CODE_H_


typedef enum
{
  EVENT_LED,
  EVENT_WIZ_PHY_LINK,
  EVENT_WIZ_PHY_DHCP,
  EVENT_WIZ_PHY_SNTP,
  EVENT_MAX,
} EventCode_t;


#endif 