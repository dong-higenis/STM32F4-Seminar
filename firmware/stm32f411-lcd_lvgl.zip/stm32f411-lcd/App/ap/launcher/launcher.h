#ifndef LAUNCHER_H_
#define LAUNCHER_H_

#ifdef __cplusplus
 extern "C" {
#endif

#include "ap_def.h"



bool launcherInit(void);
void launcherUpdate(void);


#ifdef __cplusplus
}
#endif

#endif
