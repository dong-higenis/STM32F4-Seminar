#ifndef AP_H_
#define AP_H_


#include "ap_def.h"


void apInit(void);
void apMain(void);


#endif