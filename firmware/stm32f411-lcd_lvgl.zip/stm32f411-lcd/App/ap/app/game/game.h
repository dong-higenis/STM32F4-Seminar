#ifndef GAME_H_
#define GAME_H_


#include "ap_def.h"



app_info_t *gameGetAppInfo(void);


#endif